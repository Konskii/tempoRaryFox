//
//  FillableTournamentModel.swift
//  Fox19
//
//  Created by Артём Скрипкин on 16.05.2021.
//

import Foundation

struct FillableTournamentModel {
    let name, date: String
}
