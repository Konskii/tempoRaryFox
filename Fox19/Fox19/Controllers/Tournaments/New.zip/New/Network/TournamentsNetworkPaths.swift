//
//  TournamentsNetworkPaths.swift
//  Fox19
//
//  Created by Артём Скрипкин on 14.05.2021.
//

import Foundation
enum TournamentsNetworkPaths {
    static let championship = "/api/championship"
    static let championshipMember = "/championshipmember"
}
